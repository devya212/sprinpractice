package com.nucleus;

public class Student {

}
