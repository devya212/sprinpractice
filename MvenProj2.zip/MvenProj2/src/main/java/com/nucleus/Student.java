package com.nucleus;

import java.util.List;

public class Student {
private int studentId;
private String stdName;
List<Address> address;

public int getStudentId() {
	return studentId;
}

public Student() {
	
}



public List<Address> getAddress() {
	return address;
}

public void setAddress(List<Address> address) {
	this.address = address;
}

public Student(int studentId, String stdName) {	
	this.studentId = studentId;
	this.stdName = stdName;
}

public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public String getStdName() {
	return stdName;
}
public void setStdName(String stdName) {
	this.stdName = stdName;
}

}
