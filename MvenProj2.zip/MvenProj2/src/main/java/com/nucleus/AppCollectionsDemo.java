package com.nucleus;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppCollectionsDemo {

	public static void main(String[] args) {
		/*ApplicationContext context=new ClassPathXmlApplicationContext("springconfig.xml");
		Address adr1=(Address)context.getBean("adr");
		System.out.println(adr1.getCity()+ " "+adr1.getCountry());
		List<String> landmarks=adr1.getLandmarks();
		for(String landmark: landmarks)
		{
			System.out.println(landmark);
		}*/
		ApplicationContext context=new ClassPathXmlApplicationContext("springconfig.xml");
		Student s1=(Student)context.getBean("s1");
		
		/*System.out.println(s1.getStdName()+" "+s1.getStudentId());
		s1.setStudentId(1);
		s1.setStdName("abcd");*/
		System.out.println(s1.getStdName()+" "+s1.getStudentId());
		List<Address> address=s1.getAddress();
		for(Address address1:address)
		{
			System.out.println(address1.getCity()+" "+address1.getCountry());
			for(String landmark: address1.getLandmarks())
			{
				System.out.println(landmark);
			}
		}
		/*List<String> landmarks=s1.getAddress().getLandmarks();
		System.out.println(s1.getStdName()+" "+s1.getStudentId());
		for(String landmark: landmarks)
		{
			System.out.println(landmark);
		}*/
		
		
		
		/*Student s2=(Student)context.getBean("s2");
		System.out.println(s2.getStdName()+" "+s2.getStudentId());
		*/
		
		
	}

}
